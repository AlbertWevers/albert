document.onreadystatechange = function() {
  if(document.readyState === 'complete'){
    var kmap1 = new KMaps({ 
            mapControlId: 'map_placeholder1',
            helpUrl: 'http://www.google.com',
            style: { border: 'gray solid 3px' },
            timeline: {},
            // provider: 'Esri.WorldImagery'
          });
    var kmap2 = new KMaps({ 
            mapControlId: 'map_placeholder2',
            helpUrl: 'http://www.google.com',
            style: { border: 'gray solid 3px' },
            timeline: {},
            // provider: 'Esri.WorldImagery'
          });


      // kmap1.sync(kmap2);
      // kmap2.sync(kmap1);
  }
};      
