document.onreadystatechange = function() {
  if(document.readyState === 'complete'){
      _.each([1,2], function(it){
          new KMaps({ 
            mapControlId: 'map_placeholder' + it,
            helpUrl: 'http://www.google.com',
          	style: { border: 'gray solid 3px' },
            timeline: {},
            // provider: 'Esri.WorldImagery'
          });
      })
  }
};      
