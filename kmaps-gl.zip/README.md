# kmaps-gl

[![Build Status](https://secure.travis-ci.org/archer/kmaps-gl.png?branch=master)](http://travis-ci.org/archer/kmaps-gl)

The awesome javascript library

## Installation

```
$ npm install --save-dev kmaps-gl
```

## Usage

## Documentation

## API

## License

MIT
