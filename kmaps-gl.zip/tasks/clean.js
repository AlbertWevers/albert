module.exports = {
  dist: 'dist'
};
