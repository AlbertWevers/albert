module.exports = {
  groc: {
    files: {
      src: ['lib/**/*.js']
    },
    options: {
      out: 'docs/'
    }
  }
};
