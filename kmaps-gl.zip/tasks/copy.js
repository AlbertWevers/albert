module.exports = {
    main: {
	files: [
	    // includes files within path
	    {expand: true, src: ['*.css', '!kmaps-gl.js'] , cwd: 'lib', dest: 'dist/', filter: 'isFile'},
	    {expand: true, src: ['*.png', '!kmaps-gl.js'] , cwd: 'lib', dest: 'dist/', filter: 'isFile'},
	    {expand: true, src: ['testpage/**', '!kmaps-gl.js'] , cwd: '.', dest: 'dist/'},
	    {expand: true, src: ['bower_components/**', '!kmaps-gl.js'] , cwd: '.', dest: 'dist/'},
	    {expand: true, src: ['_index.html'] , dest: 'dist/', filter: 'isFile', rename: function(dest, src) {
		'use strict';
		return dest + src.replace(/^_/gi,'');
	    }}
	],
    },
};
